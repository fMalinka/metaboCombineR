rm -r metaboCombineR_0.99.0.tar.gz
R CMD build .
R CMD INSTALL metaboCombineR_0.99.0.tar.gz
