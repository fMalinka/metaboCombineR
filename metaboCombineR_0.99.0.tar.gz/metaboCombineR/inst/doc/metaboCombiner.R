## ----style, echo = FALSE, results = 'asis'------------------------------------
BiocStyle::markdown()

## ----init, message = FALSE, echo = FALSE, results = "hide"--------------------
## Silently loading all packages
library(BiocStyle)
library(metaboCombineR)


## ----example datasets---------------------------------------------------------
data(metaboExp1)
data(metaboExp2)
data(metaboExp3)
data(metaboExp4)

## ----datmatrix example, echo=TRUE---------------------------------------------
head(metaboExp1)

## ----getRTs and getMZs--------------------------------------------------------
mzs <- getMZs(metaboExp1)
rts <- getRTs(metaboExp1)
head(mzs)
head(rts)

## ----sort data.frame by rt----------------------------------------------------
sortedRTdf <- sortDataFrameByRt(metaboExp1)
head(sortedRTdf)

## ----sort data.frame by mz----------------------------------------------------
sortedMZdf <- sortDataFrameByMz(metaboExp1)
head(sortedMZdf)

## ----runall, eval=FALSE-------------------------------------------------------
#  runMetaboCombiner(list(metaboExp1, metaboExp2, metaboExp3, metaboExp4),
#  windowsize = 5)

