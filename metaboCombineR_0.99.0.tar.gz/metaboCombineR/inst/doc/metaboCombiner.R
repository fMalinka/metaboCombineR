## ----style, echo = FALSE, results = 'asis'------------------------------------
BiocStyle::markdown()

## ----init, message = FALSE, echo = FALSE, results = "hide"--------------------
## Silently loading all packages
library(BiocStyle)
library(metaboCombineR)


