rtloessR <- function(rt1, rt2, span)
{
	pdf("rtloessTEST.pdf")
	plot(loess(rt1 ~ rt2, span=span), type="l")
	plot(predict(loess(rt1 ~ rt2, span=span)), type="l")
	dev.off()
	return(predict(loess(rt1 ~ rt2, span=span)))
}

plotFittedRT <- function(rt1, rt2, myspan, filename)
{
	myloess <- loess(rt1 ~ rt2, span=myspan)
#	myspline <- spline(rt2, rt1, xmin = min(rts$V1, rts$V2), xmax = max(rts$V1, rts$V2))
	myspline2 <- smooth.spline(rt2, rt1, spar = 0.8)

	mse_myspline2 <- sqrt(sum((predict(myspline2, x=rt2)$y - rt1)^2))
	mse_loess <- sqrt(sum((predict(myloess) - rt1)^2))

	pdf(filename)
	plot(rt2, rt1, type="l", main="Retention time approximation", xlab="RT2", ylab="RT1")
	lines(predict(myloess), x=rt2, col="red")
	lines(predict(myspline2, x=rt2), col="blue")
	legend("topleft", legend=c(paste0("loess ", myspan, " span, mse: ", round(mse_loess,2)), "original", paste0("smoothed cubic spline, mse: ", round(mse_myspline2,2))), col=c("red", "black", "blue"), lty=rep(1,3), cex=0.8)
	dev.off()

}

predictRTOrder <- function(myvector, rt1, rt2)
{
	mysplineModel <- smooth.spline(rt2, rt1, spar = 0.8)
	return(order(predict(mysplineModel, myvector)$y))
}

predictRT <- function(myvector, rt1, rt2)
{
	#mysplineModel <- smooth.spline(rt2, rt1, spar = 0.8)
	#return((predict(mysplineModel, myvector)$y))
	nrt2 <- rt2[!duplicated(rt2)]
	nrt1 <- rt1[!duplicated(rt2)]
	#mymodel <- smooth.spline(nrt1 ~ nrt2, all.knots = TRUE)
	#return((predict(mymodel, myvector)$y))
	mymodel <- approxfun(nrt2, nrt1, method = "linear", rule = 2)
	#plot(1:max(nrt2), g(1:max(nrt2)), type = "l")
	#points(nrt2, nrt1)
	return(mymodel(myvector))
}

saveCommonRTs <- function(rt1, rt2)
{
	write.csv(rt1, "rt1.csv")
	write.csv(rt2, "rt2.csv")
}

predictRT <- function(myvector, rt1, rt2)
{
	mysplineModel <- smooth.spline(rt2, rt1, spar = 0.8)
	return((predict(mysplineModel, myvector)$y))
}

orderRT <- function(myvector)
{
	return(order(myvector))
}
